﻿using System;

class Program
{
    static void Main()
    {
        int[] numbers = { 5, -3, 8, -2, 0, -7, 4 };
        int positive = 0;
        int negative = 0;

        for (int i = 0; i < numbers.Length; i++)
        {
            if (numbers[i] >= 0)
                positive++;
            else
                negative++;
        }

        Console.WriteLine("Positive numbers: " + positive);
        Console.WriteLine("Negative numbers: " + negative);
    }
}