using System;

namespace LoginValidationApp
{
    class Program
    {
        static void Main(string[] args)
        {
            string username = "admin";
            string password = "1234";
            int attempts = 3;

            while (attempts > 0)
            {
                Console.Write("Enter username: ");
                string u = Console.ReadLine();

                Console.Write("Enter password: ");
                string p = Console.ReadLine();

                if (u == username && p == password)
                {
                    Console.WriteLine("Login Successful");
                    break;
                }
                else
                {
                    attempts--;
                    Console.WriteLine("Invalid credentials. Attempts left: " + attempts);
                }
            }

            if (attempts == 0)
                Console.WriteLine("Login Failed");

            Console.ReadLine();
        }
    }
}