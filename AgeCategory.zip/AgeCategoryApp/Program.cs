using System;

namespace AgeCategoryApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter age: ");
            int age = Convert.ToInt32(Console.ReadLine());

            if (age < 12)
                Console.WriteLine("You are kid");
            else if (age >= 12 && age <= 17)
                Console.WriteLine("You are teenager");
            else if (age >= 18 && age <= 60)
                Console.WriteLine("You are adult");
            else
                Console.WriteLine("You are senior citizen");

            Console.ReadLine();
        }
    }
}