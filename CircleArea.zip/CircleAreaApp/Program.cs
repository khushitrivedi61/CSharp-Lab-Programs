using System;

namespace CircleAreaApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter radius: ");
            double r = Convert.ToDouble(Console.ReadLine());
            double area = 3.14 * r * r;
            Console.WriteLine("Area of circle is: " + area);
            Console.ReadLine();
        }
    }
}